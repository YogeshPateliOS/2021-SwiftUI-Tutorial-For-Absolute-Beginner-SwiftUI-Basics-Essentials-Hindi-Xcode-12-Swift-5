//
//  SwiftUI_LandmarksApp.swift
//  SwiftUI_Landmarks
//
//  Created by Yogesh Patel on 20/03/21.
//

import SwiftUI

@main
struct SwiftUI_LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
